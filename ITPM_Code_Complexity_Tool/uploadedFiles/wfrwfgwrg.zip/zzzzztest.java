public class ChatAPP{
private sting client;
private sting server ;
for(int x = 0 ; x< 20 ; x++){
clint = client +1 ;
}
if(p ==1){
i++;
for(j= 0 ; J++ ; j < 10){
val = val + 1
else if(p == 2 )
i--;
else
return 0;
}
